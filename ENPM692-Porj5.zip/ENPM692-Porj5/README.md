# ENPM692-Porj5

Final project for 692

The demo runs without parameters. Only dependency is Pygame.
Shows RRT from start -> goal
Then RRT from goal -> start

It then optimises both paths.
Returns the best path.

The catkin workspace will only work with the included world. It will move from its start position to position (4, 4) using Hybrid RRT for pathfinding
